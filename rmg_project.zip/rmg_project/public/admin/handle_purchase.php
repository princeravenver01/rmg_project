<?php
// Set a clear error handler.
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    session_start();
    $_SESSION['message'] = "A fatal error occurred. Error: $errstr in $errfile on line $errline";
    $_SESSION['msg_type'] = "danger";
    if (!headers_sent()) { header('Location: purchase_record.php'); }
    exit();
});

session_start();
require_once '../../src/includes/db_connect.php'; 

if (($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff') || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: purchase_record.php'); exit();
}

$package_id = isset($_POST['package_id']) ? (int)$_POST['package_id'] : 0;
$account_type = isset($_POST['account_type']) ? trim($_POST['account_type']) : '';
// This now correctly gets the value from the hidden input
$num_heads = isset($_POST['num_heads']) ? (int)$_POST['num_heads'] : 0;
$sale_id_input = isset($_POST['sale_id']) ? trim($_POST['sale_id']) : '';
$admin_id = $_SESSION['user_id'];
$source_sale_id = null;

// --- Validation Logic ---
if ($package_id <= 0 || !in_array($num_heads, [1, 3, 7, 0]) || empty($account_type)) { // allow 0 temporarily
     if($num_heads === 0) { // If it's 0, it means the field wasn't sent, which is an error
        $_SESSION['message'] = "Number of heads was not submitted. Please try again.";
     } else {
        $_SESSION['message'] = "Invalid input. Please ensure all fields are selected.";
     }
    $_SESSION['msg_type'] = "danger";
    header('Location: purchase_record.php'); exit();
}

if ($account_type === 'Paid Account') {
    if (empty($sale_id_input)) {
        $_SESSION['message'] = "A POS Sale ID is required for Paid Accounts.";
        $_SESSION['msg_type'] = "danger";
        header('Location: purchase_record.php'); exit();
    }
    
    $source_sale_id = (int)preg_replace('/[^0-9]/', '', $sale_id_input);

    $stmt_sale = $mysqli->prepare("SELECT id FROM product_sales WHERE id = ? AND is_code_generated = 0");
    $stmt_sale->bind_param("i", $source_sale_id);
    $stmt_sale->execute();
    if ($stmt_sale->get_result()->num_rows !== 1) {
        $_SESSION['message'] = "Invalid or already used Sale ID (#$source_sale_id).";
        $_SESSION['msg_type'] = "danger";
        header('Location: purchase_record.php'); exit();
    }
    $stmt_sale->close();

    $paid_account_barcode = '11110000';
    $stmt_items = $mysqli->prepare("SELECT SUM(psi.quantity) as total_quantity FROM product_sale_items psi JOIN products p ON psi.product_id = p.id WHERE psi.sale_id = ? AND p.barcode = ?");
    $stmt_items->bind_param("is", $source_sale_id, $paid_account_barcode);
    $stmt_items->execute();
    $item = $stmt_items->get_result()->fetch_assoc();
    
    if (!$item || $item['total_quantity'] == 0) {
        $_SESSION['message'] = "This Sale ID does not contain any Paid Account Package purchases.";
        $_SESSION['msg_type'] = "danger";
        header('Location: purchase_record.php'); exit();
    }
    
    if ($item['total_quantity'] != $num_heads) {
        $_SESSION['message'] = "The number of heads selected ($num_heads) does not match the quantity in Sale ID #$source_sale_id (which has " . $item['total_quantity'] . " heads).";
        $_SESSION['msg_type'] = "danger";
        header('Location: purchase_record.php'); exit();
    }
    $stmt_items->close();
}

$stmt_pkg = $mysqli->prepare("SELECT price, points_value FROM packages WHERE id = ?");
$stmt_pkg->bind_param("i", $package_id);
$stmt_pkg->execute();
$result_pkg = $stmt_pkg->get_result();
if ($result_pkg->num_rows !== 1) {
    $_SESSION['message'] = "Invalid package selected."; $_SESSION['msg_type'] = "danger";
    header('Location: purchase_record.php'); exit();
}
$package = $result_pkg->fetch_assoc();
$stmt_pkg->close();

$price_paid = ($account_type === 'FS Account') ? 0.00 : $package['price'];
$points_earned = $package['points_value'];

$mysqli->begin_transaction();
$generated_code_ids = [];
try {
    if ($source_sale_id !== null) {
        $stmt_mark = $mysqli->prepare("UPDATE product_sales SET is_code_generated = 1 WHERE id = ?");
        $stmt_mark->bind_param("i", $source_sale_id);
        $stmt_mark->execute();
        $stmt_mark->close();
    }

    $stmt_code = $mysqli->prepare("INSERT INTO activation_codes (code, package_id, account_type, generated_by_id, source_sale_id) VALUES (?, ?, ?, ?, ?)");
    $stmt_hist = $mysqli->prepare("INSERT INTO purchase_history (package_id, account_type, activation_code_id, price_paid, points_earned, payment_method, processed_by_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    for ($i = 0; $i < $num_heads; $i++) {
        $code = 'RMG-' . strtoupper(bin2hex(random_bytes(4)));
        $stmt_code->bind_param("sisis", $code, $package_id, $account_type, $admin_id, $source_sale_id);
        $stmt_code->execute();
        $activation_code_id = $mysqli->insert_id;
        if ($activation_code_id <= 0) { throw new Exception("Code generation failed."); }
        $generated_code_ids[] = $activation_code_id;

        $payment_method = 'Admin Generated';
        $stmt_hist->bind_param("isiidisi", $package_id, $account_type, $activation_code_id, $price_paid, $points_earned, $payment_method, $admin_id);
        $stmt_hist->execute();
    }
    $stmt_code->close();
    $stmt_hist->close();

    $mysqli->commit();
    
    $_SESSION['generated_codes'] = $generated_code_ids;
    header('Location: codes_generated.php');
    exit();

} catch (Exception $e) {
    $mysqli->rollback();
    $_SESSION['message'] = "Error: Transaction failed. " . $e->getMessage();
    $_SESSION['msg_type'] = "danger";
    header('Location: purchase_record.php');
    exit();
}
$mysqli->close();
?>